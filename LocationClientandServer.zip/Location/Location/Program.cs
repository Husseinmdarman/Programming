﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.IO;


namespace location
{


  static public  class whois
    {
        /// <summary>
        /// check against internetprotocols to decide which to use
        /// </summary>

        static public string internetprotocol(string check)
        {
            string http1 = "-h0";
            string http11 = "-h1";
            string http09 = "-h9";

            if (check == http1)
            {
                return http1;
            }
            else if (check == http11)
            {
                return http11;
            }
            else if (check == http09)
            {
                return http09;
            }
            else
            {
                return "unrecoginsed command";
            }

        }
      
        static public void containstring(string stuff, out string contain)
        {
            //split the string at text/plain

            string[] s = stuff.Split(new string[] { "text/plain\r\n\r\n" }, 2, StringSplitOptions.RemoveEmptyEntries);
            if (s.Length == 2)
            {
                //latter half of the array contains the correct location
                contain = s[1];
                //trim any trialing characters
                contain = contain.Trim();
            }
            else
            {

                contain = stuff;
            }
            contain = contain.Trim();
        }
        /// <summary>
        /// Have all the http style of request within this method
        /// </summary>
        /// <param name="style"></param>
        /// <param name="args"></param>
        static public void styleofrequest(string style, string[] args)
        {   
            int c; 
            // client info
            TcpClient client = new TcpClient();


            //set variables for the port and host
            int findhost = -1;
            string hostname;
            string portnumber;
            int portLocation;
            //finds the host position in array and the host name
            Findhost(args, out findhost, out hostname);
            //remove host from list of arguement 
            
            if (findhost != -1 )
            {
                //host number is not equal to -1 therefore it had found -h in the arguements
                try
                {
                    //removes -h and hostname from array
                    args = args.Where(w => w != args[findhost + 1]).ToArray();
                    args = args.Where(w => w != args[findhost]).ToArray();
                }
                catch
                {
                    //catches if there is a -h but no hostname
                    Console.WriteLine("no hostname ");
                    Environment.Exit(0);
                }
               
            }

            //find the port number in the array and the -p (portlocation) in the array
            FindPort(args, out portnumber, out portLocation);
            //if portlocation and findhost are still default to -1 then run defaults case
            if (portLocation == -1 && findhost == -1)
            {
                //connect to default whois and port number
                client.Connect("whois.net.dcs.hull.ac.uk", 43);
                //set the client's receive and send timouts
                client.ReceiveTimeout = 2000;
                client.SendTimeout = 2000;


            }
            else if (portLocation == -1)
            {
               
                //no port number therefore default 43 is user with the host
                    client.Connect(hostname, 43);
                    client.ReceiveTimeout = 2000;
                    client.SendTimeout = 2000;
                
               
            }
            else
            {
                int port =0;
                //Remove port from list of args
                if (portLocation != -1)
                {
                    
                    try
                    { //removing port number and location of -h from the array
                        port = int.Parse(portnumber);
                        args = args.Where(w => w != args[portLocation + 1]).ToArray();
                        args = args.Where(w => w != args[portLocation]).ToArray();
                    }
                    catch
                    {
                        //couldn't remove port location e.i 43, 80,90 therefore no port is specified
                        Console.WriteLine("no port location");
                        Environment.Exit(0);

                    }
                }
                //connect to the hostname and port provided by the arguements
                client.Connect(hostname, port);
                client.ReceiveTimeout = 2000;
                client.SendTimeout = 2000;

            }





            StreamWriter sw = new StreamWriter(client.GetStream());
            StreamReader sr = new StreamReader(client.GetStream());



            

            //style contains the protocols
            switch (style)
            {
                    //case if its http/0.9 protocol
                case "-h9":
                    //if  arguement length is only 1 then its a simple get
                    if (args.Length == 1)
                    {
                        sw.WriteLine("GET " + "/" + args[0]);
                        sw.Flush();

                        string contain = sr.ReadToEnd();

                        try
                        {
                            containstring(contain, out contain);
                            Console.WriteLine(args[0] + " is " + contain);


                        }
                        catch
                        {
                            Console.WriteLine(args[0] + " is " + contain);


                        }
                    }
                    if (args.Length == 2)
                    {
                        //if arguement length is 2 then it is a put

                        sw.WriteLine("PUT " + "/" + args[0] + "\r\n" + "\r\n" + args[1]);
                        sw.Flush();
                        string contain = sr.ReadToEnd();
                        containstring(contain, out contain);
                        Console.WriteLine(args[0] + " location changed to be " + args[1]);

                    }

                    break;
                ///http1.0 protocals
                case "-h0":
                    {
                        if (args.Length == 1)
                        {
                            sw.WriteLine("GET " + "/" + args[0] + " " + "HTTP/1.0" + "\r\n");
                            sw.Flush();
                            string contain = sr.ReadToEnd();
                            string[] s;
                            try
                            {
                                // split the response by the server to remove any uncessary factors from the location
                                s = contain.Split(new string[] { "path=/\r\n\r\n" }, 2, StringSplitOptions.RemoveEmptyEntries);
                                if (s.Length == 2)
                                {
                                    Console.WriteLine(args[0] + " is " + s[1]);
                                }
                                else
                                {
                                    //split contain so that you can see the location
                                    containstring(contain, out contain);
                                    contain = contain.Trim();

                                    Console.WriteLine(args[0] + " is " + contain);
                                }

                            }
                            catch
                            {


                            }


                        }
                        if (args.Length == 2)
                        {
                            //if arguement length is 2 then it is a post request
                            sw.WriteLine("POST " + "/" + args[0] + " HTTP/1.0" + "\r\n" + "Content-Length: " + args[1].Count() + "\r\n" + "\r\n" + args[1]);
                            sw.Flush();
                            //read to the end of the stream
                            string contain = sr.ReadToEnd();
                            //if something is returned then location has been changed
                            Console.WriteLine(args[0] + " location changed to be " + args[1]);
                        }
                        break;

                        ///http protocal 1.0

                    }
                case "-h1":
                    {
                        if (args.Length == 1)
                        {
                            string[] containment = new string[100];
                            ///for the -h1 protocol
                            try
                            {
                                sw.WriteLine("GET " + "/" + args[0] + " HTTP/1.1" + "\r\n" + "Host: " + hostname + "\r\n");
                                sw.Flush();
                                string contain = sr.ReadToEnd();
                                containstring(contain, out contain);
                                Console.WriteLine(args[0] + " is " + contain);
                            }
                            catch
                            {
                                /// use the catch to handle the readline
                                /// define a variable to hold the Readline.
                                /// make the first arguement in the array args[0] is 
                                sw.WriteLine("GET " + "/" + args[0] + " HTTP/1.1" + "\r\n" + "Host: " + hostname + "\r\n");
                                sw.Flush();
                                string contain;
                                do
                                {
                                    contain = sr.ReadLine();
                                }
                                while (contain != "");
                                if (contain == "")
                                {
                                    /// add args to the array as first argument
                                    containment[0] = args[0] + " is ";

                                    int t = 1;
                                    try
                                    {
                                        do
                                        {
                                            //reads every line from the stream and saves it in containment
                                            contain = sr.ReadLine();
                                            containment[t] = contain;
                                            //increment counter
                                            t++;
                                        }
                                        while (t < 20);
                                    }
                                    catch
                                    {

                                        for (int i = 0; i < containment.Length; i++)
                                        {
                                            if (i == 0)
                                            {
                                                int p = 1;
                                                do
                                                {
                                                    containment[0] = containment[0] + containment[0 + 1];
                                                    break;

                                                    p++;
                                                }
                                                while (containment[p] != null);
                                            }
                                            if (containment[i] == null)
                                            {
                                                break;
                                            }
                                            else
                                            {
                                                do
                                                {
                                                    if (i == 1)
                                                    {
                                                        i++;
                                                    }
                                                    else
                                                    {
                                                        Console.WriteLine(containment[i]);
                                                        i++;
                                                    }
                                                }
                                                while (containment[i] != null);
                                                break;
                                            }
                                        }

                                    }

                                  
                                }
                            }
                        }
                        if (args.Length == 2)
                        {
                            

                            sw.WriteLine("POST " + "/" + args[0] + " " + "HTTP/1.1" + "\r\n" + "Host: " + hostname + "\r\n" + "Content-Length: " + args[1].Count() + "\r\n" + "\r\n" + args[1]);
                            sw.Flush();
                            string contain = sr.ReadToEnd();
                            containstring(contain, out contain);
                            Console.WriteLine(args[0] + " location changed to be " + args[1]);

                        }
                        break;
                    }

                default:
                    {
                        if (args.Length == 2)
                        {
                            /// Console.WriteLine(args[0] + " " + args[1]  );

                            sw.WriteLine(args[0] + " " + args[1]);
                            sw.Flush();
                            string capture = sr.ReadToEnd();
                            if (capture == "OK\r\n")
                            {
                            Console.WriteLine(args[0] + " location changed to be " + args[1]);
                            }

                        }

                        else if (args.Length == 1)
                        {
                            sw.WriteLine(args[0]);

                            sw.Flush();
                            string capture = "empty";
                            //Console.WriteLine(sr.ReadToEnd());
                            try
                            {
                                capture = sr.ReadToEnd();

                            }

                            catch { Console.WriteLine("connection has timedout"); }

                            if (capture != "empty")
                            {
                                Console.WriteLine(args[0] + " is " + capture);
                            }
                        }
                        else Console.WriteLine("ERROR: Wrong number of arguments");
                        break;
                    }




            }
        }

        /// <summary>
        /// Finds port and returns position of port and port number
        /// </summary>
        /// <param name="args"></param>
        /// <param name="portnumber"></param>
        /// <param name="portlocation"></param>
        /// <returns></returns>
        static public void FindPort(string[] args, out string portnumber, out int portlocation)
        {
            portlocation = -1;
            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "-p")
                {
                    portlocation = i;
                  
                    break;
                }


            }
            try
            {
                portnumber = args[portlocation + 1];
            }
            catch
            {
                portnumber = "empty";
            }
        }
        /// <summary>
        /// extracts the hostname from the arguements
        /// </summary>
        /// <param name="args"></param>
        /// <param name="host"></param>
        /// <returns></returns>
        static public int Findhost(string[] args, out int host, out string hostname)
        {
            host = -1;
            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "-h")
                {
                    host = i;
                    break;


                }
                else
                {
                    host = -1;
                   
                }

            }

            ///once -h is found move on to the right for the hostname
            ///
            string r = "empty";
            if (host != -1)
            {
                try
                {
                    hostname = args[host + 1];
                    r = hostname;

                }
                catch
                {
                    hostname = "empty";
                    r = hostname;
                }
            }

            hostname = r;
            ///return the hostname and the interger where the host was found
            return host;

        }
        static public string protocal(string[] args, out int remove)
        {
            string style = "default";
            remove = -1;
            for (int i = 0; i < args.Length; i++)
            {
                style = internetprotocol(args[i]);
                if (style == args[i])
                {
                    remove = i;
                    break;
                }
            }

            return style;
        }

       static public bool verifyhost(string[] args, out int number)
        {
            int host;
            string hostname;
            Findhost(args, out host, out hostname);
            number = host;
            if(hostname == "empty")
            {
                return false;
            }
            else
            {
                return true;
            }
            //loop through array

        }
        /// <summary>
        /// Add a method to loop through args and determine which to use
        /// </summary>
        /// <param name="args"></param>
        static public void Main(string[] args)
        {
            
            int remove;
            string style = protocal(args, out remove);

            if (style == "unrecoginsed command")
            {

            }
            else
            {
                args = args.Where(w => w != args[remove]).ToArray();
            }
            styleofrequest(style, args);



        }





    }
}
The following zip file contains:

The location server solution and it's executable in a folder named: locationserver
The location client solution and it's executable in a folder named: location
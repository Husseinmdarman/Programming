﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.IO;
using System.Net;
using System.Threading;


namespace locationserver
{
    class Program
    {
        //Dictionary to store user name and location
        static Dictionary<string, string> d = new Dictionary<string, string>();

        static void Main(string[] args)
        {

            runServer();


        }


        static void runServer()
        {
            Console.WriteLine("Server is up and running");
            TcpListener listener;
            Socket connection;
            handler Requesthandler;


            try
            {

                //create a new listener and start it
                listener = new TcpListener(IPAddress.Any, 43);
                listener.Start();
                while (true)
                {

                    connection = listener.AcceptSocket();
                    // Console.WriteLine("Server connected");
                    Console.WriteLine("connection recieved");
                    //hold readlines in a string array
                    string[] holdreadlines = new string[20];
                    ///invoke handler class
                    Requesthandler = new handler();
                    //create new thread to invoke the handler public methods
                    Thread t = new Thread(() => Requesthandler.doRequest(connection, holdreadlines, d));
                    ///start the thread   
                    t.Start();


                }
            }
            catch (Exception e)
            {
                //display error message if it didn't work
                Console.WriteLine(e.ToString());
            }
        }
    }
    class handler
    {
        public void doRequest(Socket connection, string[] holdreadlines, Dictionary<string, string> d)
        {
            //create a new newtwork stream object
            NetworkStream socketStream;

            //Let socketstream accept the connect
            socketStream = new NetworkStream(connection);

            //set read and write timeouts to a second
            socketStream.ReadTimeout = 1000;
            socketStream.WriteTimeout = 1000;

            //streamWriter and StreamReader intialise a new instance for the specified network stream
            StreamWriter sw = new StreamWriter(socketStream);
            StreamReader sr = new StreamReader(socketStream);

            try
            {



                //start point for the array
                int i = 0;
                //creat array to store string values that a read
                string[] s = new string[10];
                //set the first instance in the array as empty
                s[0] = "empty";
                //check first instance against this string
                String line = "empty";
                try
                {
                    //reads to the end of the stream
                    while (!sr.EndOfStream)
                    {
                        //reads a line from the stream
                        line = sr.ReadLine();

                        if (line != "")
                        {
                            //stores read line in array
                            holdreadlines[i] = line;
                            //increment counter for the next series of line
                            i++;
                        }
                        //writes out the line
                        Console.WriteLine(line);
                    }
                }
                catch
                {
                    //catches exception that is thrown at the end of the stream
                    ///saves the Array into the s Array 
                    s = holdreadlines;
                }

                if (s[0] != "empty")
                {
                    //if s[0] is not empty it will split the string at the " /" removing the put, post, and get requests from the username and location details

                    s = s[0].Split(new string[] { " /" }, 2, StringSplitOptions.RemoveEmptyEntries);

                    try
                    {
                        //creates a new array of t
                        string[] t = new string[10];
                        //stores split string in t
                        t[0] = s[0];
                        t[1] = s[1];
                        //stores the holdreadlines in t
                        t[2] = holdreadlines[1];
                        t[3] = holdreadlines[2];
                        t[4] = holdreadlines[3];
                        //copy all of t into holdreadlines
                        holdreadlines = t;

                    }
                    catch { }
                }




                //use the get, post and put requests
                if (holdreadlines[0] == "GET" && holdreadlines[1] != null || holdreadlines[0] == "PUT" && holdreadlines[1] != null || holdreadlines[0] == "POST" && holdreadlines[1] != null)
                {
                    switch (s[0])
                    {


                        case "GET":
                            // split up lines to recoginse  other http protocols
                            /// is there always a space between user and protocols
                            /// answer to that is yes
                            /// add if  statements to select the correct protocol.

                            ///splitting by section  works
                            ///second entry in array is style of request
                            string[] sections = holdreadlines[1].Split(new string[] { " " }, 2, StringSplitOptions.RemoveEmptyEntries);

                            if (sections.Length == 2)
                            {
                                //checks if get requests is either in the style of http/1.0 or http/1.1
                                try
                                {
                                    switch (sections[1])
                                    {


                                        case "HTTP/1.0":
                                            {
                                                try
                                                {
                                                    Console.WriteLine(sections[0] + " is at " + d[sections[0]]);
                                                    sw.WriteLine("HTTP/1.0 200 OK" + "\r" + "\n" + "Content-Type: text/plain" + "\r" + "\n" + "\r" + "\n" + d[sections[0]]);
                                                    sw.Flush();



                                                }
                                                catch
                                                {
                                                    sw.WriteLine("HTTP/1.0 404 Not Found" + "\r\n" + "Content-Type: text/plain" + "\r\n");
                                                    sw.Flush();
                                                }
                                                break;
                                            }

                                        case "HTTP/1.1":
                                            {
                                                try
                                                {
                                                    Console.WriteLine(sections[0] + " is at " + d[sections[0]]);
                                                    sw.WriteLine("HTTP/1.1 200 OK" + "\r" + "\n" + "Content-Type: text/plain" + "\r" + "\n" + "" + "\r" + "\n" + d[sections[0]]);
                                                    sw.Flush();
                                                }
                                                catch
                                                {
                                                    sw.WriteLine("HTTP/1.1 404 Not Found" + "\r\n" + "Content-Type: text/plain" + "\r\n" + "");
                                                    sw.Flush();
                                                }
                                                break;
                                            }


                                    }
                                }
                                catch { }
                            }

                            //if sections is only one then it is a http/0.9 request
                            if (sections.Length == 1)
                            {
                                try
                                {


                                    Console.WriteLine(holdreadlines[1] + " is at " + d[holdreadlines[1]]);
                                    sw.WriteLine("HTTP/0.9 200 OK" + "\r" + "\n" + "Content-Type: text/plain" + "\r" + "\n" + "\r" + "\n" + d[holdreadlines[1]]);
                                    sw.Flush();
                                }
                                catch
                                {
                                    sw.WriteLine("HTTP/0.9 404 Not Found" + "\r\n" + "Content-Type: text/plain" + "\r\n");
                                    sw.Flush();
                                }
                            }
                            break;
                        case "PUT":
                            {
                                try
                                {
                                    Console.WriteLine(holdreadlines[1] + " is at " + holdreadlines[2]);
                                    if (!(d.ContainsKey(holdreadlines[1])))
                                    {
                                        //Add user to the dictionary
                                        d.Add(holdreadlines[1], holdreadlines[2]);
                                        sw.WriteLine("HTTP/0.9 200 OK" + "\r\n" + "Content-Type: text/plain" + "\r\n");
                                        sw.Flush();
                                    }
                                    else if (d.ContainsKey(holdreadlines[1]))
                                    {
                                        //update the user location
                                        d[holdreadlines[1]] = holdreadlines[2];
                                        sw.WriteLine("HTTP/0.9 200 OK" + "\r\n" + "Content-Type: text/plain" + "\r\n");
                                        sw.Flush();
                                    }
                                }
                                catch
                                {
                                    sw.WriteLine("");
                                    sw.Flush();
                                }
                                break;
                            }

                        case "POST":
                            {
                                ///split the http statement
                                string[] section = holdreadlines[1].Split(new string[] { " " }, 2, StringSplitOptions.RemoveEmptyEntries);

                                if (section[1] == "HTTP/1.0")
                                {
                                    if (d.ContainsKey(section[0]))
                                    {
                                        try
                                        {

                                            //update dictionary to save new user location
                                            d[section[0]] = holdreadlines[3];
                                            sw.WriteLine("HTTP/1.0 200 OK" + "\r\n" + "Content-Type: text/plain" + "\r\n");
                                            sw.Flush();
                                        }
                                        catch
                                        {
                                            //if user is not in dictionary: return this
                                            sw.WriteLine("HTTP/1.0 404 Not Found" + "\r\n" + "Content-Type: text/plain" + "\r\n");
                                            sw.Flush();
                                        }
                                    }
                                    //update user


                                }
                                else if (section[1] == "HTTP/1.1")
                                {
                                    try
                                    {
                                        if (d.ContainsKey(section[0]))
                                        {
                                            d[section[0]] = holdreadlines[4];
                                            sw.WriteLine("HTTP/1.1 200 OK" + "\r\n" + "Content-Type: text/plain" + "\r\n" + "");
                                            sw.Flush();
                                        }
                                    }
                                    catch
                                    {
                                        sw.WriteLine("HTTP/1.1 404 Not Found" + "\r\n" + "Content-Type: text/plain" + "\r\n");
                                        sw.Flush();
                                    }

                                }

                                break;
                            }
                    }
                }
                else
                {
                    //else it must be a whois request
                    //split at the space
                    s = s[0].Split(new string[] { " " }, 2, StringSplitOptions.RemoveEmptyEntries);


                    if (s.Length == 1)
                    {
                        if (d.ContainsKey(s[0]))
                        {
                            Console.WriteLine(s[0] + " is at " + d[s[0]]);
                            sw.WriteLine(d[s[0]]);
                            sw.Flush();
                        }
                        else
                        {
                            Console.WriteLine("ERROR: no entries found " + "/r" + "/n");
                            sw.WriteLine("ERROR: no entries found");
                            sw.Flush();
                        }
                    }
                    if (s.Length == 2)
                    {
                        if (!(d.ContainsKey(s[0])))
                        {
                            //add user to the dictionary
                            d.Add(s[0], s[1]);
                            d[s[0]] = s[1];

                            sw.WriteLine("OK");
                            sw.Flush();
                        }
                        else if (d.ContainsKey(s[0]))
                        {
                            ///update user information in dictionary
                            d[s[0]] = s[1];

                            sw.WriteLine("OK");
                            sw.Flush();
                        }
                    }
                }

            }
            catch (Exception)
            {
                Console.WriteLine("server timeout");
            }
            socketStream.Close();
            connection.Close();
        }


    }

}


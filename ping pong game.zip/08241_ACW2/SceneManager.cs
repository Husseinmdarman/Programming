﻿using System;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;

namespace PongGame
{
    class SceneManager : GameWindow
    {
        Scene scene;
        static int width = 0;
        static int height = 0;

        public delegate void SceneDelegate(FrameEventArgs e);
        public SceneDelegate renderer;
        public SceneDelegate updater;

        public SceneManager()
        {
            Mouse.ButtonDown += Mouse_ButtonDown;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            GL.Enable(EnableCap.DepthTest);

            base.Width = 1024;
            base.Height = 512;
            SceneManager.width = Width;
            SceneManager.height = Height;

            //Load the GUI
            GUI.SetUpGUI(Width, Height);

            scene = new MainMenuScene(this);
        }

        protected override void OnUpdateFrame(FrameEventArgs e)
        {
            updater(e);
        }
        
        protected override void OnRenderFrame(FrameEventArgs e)
        {
            base.OnRenderFrame(e);

            renderer(e);

            GL.Flush();
            SwapBuffers();
        }

        private void Mouse_ButtonDown(object sender, MouseButtonEventArgs e)
        {
            switch (e.Button)
            {
                case MouseButton.Left:
                   ///check whether mouse is in bounds of the label "game start and if it is start game otherwise nothing

                    StartNewGame();
                    break;
                case MouseButton.Right:
                    StartMenu();
                    break;
                   
            }
        }

        public void StartNewGame()
        {
            scene = new GameScene(this);
        }
      
        public void StartMenu()
        {
            scene = new MainMenuScene(this);
        }

        public static int WindowWidth
        {
            get { return width; }
        }

        public static int WindowHeight
        {
            get { return height; }
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);

            GL.Viewport(ClientRectangle.X, ClientRectangle.Y, ClientRectangle.Width, ClientRectangle.Height);
            SceneManager.width = Width;
            SceneManager.height = Height;

            //Load the GUI
            GUI.SetUpGUI(Width, Height);
        }
    }

}


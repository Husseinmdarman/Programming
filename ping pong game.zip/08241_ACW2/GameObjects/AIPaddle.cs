﻿using System;
using OpenTK;

namespace PongGame
{
    class AIPaddle : Paddle
    {
        public AIPaddle(int x, int y) : base(x, y)
        {  
        }

        /// <summary>
        /// update update velocity if the screenheight doesn't affect it.
        /// </summary>
        /// <param name="dt"></param>
        public override void Update(float dt)
        {
            position += velocity;

            if (position.Y < 0 - PaddleArea().Y) position.Y = 0 - PaddleArea().Y;
            else if (position.Y > SceneManager.WindowHeight + PaddleArea().Y) position.Y = SceneManager.WindowHeight + PaddleArea().Y;
        }

        public void Move(Vector2 ballPosition)
        {
            velocity.Y += (ballPosition.Y - position.Y) * 0.005f;
        }
    }
}

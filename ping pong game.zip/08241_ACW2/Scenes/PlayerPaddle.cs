﻿using System;

namespace PongGame
{
    class PlayerPaddle : Paddle
    {
        public PlayerPaddle(int x, int y) : base(x, y)
        { 
        }
      
       

        public override void Update(float dt)
        {
        }

        public void Move(int dy)
        {   ///fix the scenemanager windowheight problem should position the whole of the paddle
            position.Y += dy;

            if (position.Y < 0 - PaddleArea().Y) position.Y = 0 - PaddleArea().Y;
              else if (position.Y > SceneManager.WindowHeight + PaddleArea().Y ) position.Y = SceneManager.WindowHeight + PaddleArea().Y;
        
    }
}
}
﻿using System;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections.Generic;

namespace PongGame
{
    
   class EndGame : Scene, IScene
    {
         public EndGame(SceneManager sceneManager, List<int> playerScore) : base(sceneManager)
        {
            // Set the title of the window
            sceneManager.Title = "Pong - EndGame";
            // Set the Render and Update delegates to the Update and Render methods of this class
            sceneManager.renderer = Render;
            sceneManager.updater = Update;
        }


         public void Update(FrameEventArgs e)
         {

         }

         public void Render(FrameEventArgs e)
         {
             GL.Viewport(0, 0, sceneManager.Width, sceneManager.Height);
             GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

             GL.MatrixMode(MatrixMode.Projection);
             GL.LoadIdentity();
             GL.Ortho(0, sceneManager.Width, 0, sceneManager.Height, -1, 1);

             GUI.clearColour = Color.CornflowerBlue;

             //Display the Title
             float width = sceneManager.Width, height = sceneManager.Height, fontSize = Math.Min(width, height) / 10f;
             GUI.Label(new Rectangle(0, (int)(fontSize / 2f), (int)width, (int)(fontSize * 2f)), "End Game", (int)fontSize, StringAlignment.Center);
             GUI.Label(new Rectangle(0, (int)(fontSize / 2f), (int)width, (int)(fontSize * 12f)), "Please Enter Your Name", (int)fontSize, StringAlignment.Center);
             ///type in the  player name and display while typing continue displaying it 
             

             GUI.Render();
         }
       
    }
}

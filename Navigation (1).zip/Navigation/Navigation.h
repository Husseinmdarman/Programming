#pragma once

#include <fstream>
#include <string>
using namespace std;

class Navigation
{
public:
	Navigation();
	~Navigation();

	bool BuildNetwork(string fileNamePlaces, string fileNameLinks);
	bool ProcessCommand(string commandString);

	float ArcLength(float startNorth, float startEast, float endNorth, float endEast) const;

private:
	void LLtoUTM(const float Lat, const float Long, float &UTMNorthing, float &UTMEasting) const;

	ofstream m_outFile;
};


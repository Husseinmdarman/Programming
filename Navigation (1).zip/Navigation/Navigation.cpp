#include "Navigation.h"
#include <iostream>
#include <iomanip>
#include <sstream>
using namespace std;


Navigation::Navigation() : m_outFile("Output.txt")
{
}

Navigation::~Navigation()
{
}

bool Navigation::ProcessCommand(string commandString)
{
	istringstream inString(commandString);
	string command;
	inString >> command;

	// Add code here

	return false;
}

bool Navigation::BuildNetwork(string fileNamePlaces, string fileNameLinks)
{
	fstream finPlaces(fileNamePlaces);
	fstream finLinks(fileNameLinks);
	if (finPlaces.fail() || finLinks.fail()) return false;

	// Add code here

	return false;
}



// ###################################################################################
// ##                                                                               ##
// ##  The following methods are used to calculate the distance between two nodes.  ##
// ##  DO NOT edit either of these methods!                                         ##
// ##                                                                               ##
// ###################################################################################

// **** DO NOT EDIT THIS METHOD ****
float Navigation::ArcLength(float startNorth, float startEast, float endNorth, float endEast) const
{
	float UTMNorthingStart;
	float UTMEastingStart;
	float UTMNorthingEnd;
	float UTMEastingEnd;

	LLtoUTM(startNorth, startEast, UTMNorthingStart, UTMEastingStart);
	LLtoUTM(endNorth, endEast, UTMNorthingEnd, UTMEastingEnd);

	float dNorth = UTMNorthingEnd - UTMNorthingStart;
	float dEast = UTMEastingEnd - UTMEastingStart;

	return sqrt(dNorth*dNorth + dEast*dEast) * 0.001f;
}

// **** DO NOT EDIT THIS METHOD ****
void Navigation::LLtoUTM(const float Lat, const float Long, float &UTMNorthing, float &UTMEasting) const
{
	//converts lat/long to UTM coords.  Equations from USGS Bulletin 1532 
	//East Longitudes are positive, West longitudes are negative. 
	//North latitudes are positive, South latitudes are negative
	//Lat and Long are in decimal degrees
	//Original code by Chuck Gantz- chuck.gantz@globalstar.com (http://www.gpsy.com/gpsinfo/geotoutm/)
	//Adapted by Darren McKie

	const float PI = 3.14159265f, FOURTHPI = PI/4.0f, DEG2RAD = PI/180.0f;

	float a = 6378137;
	float eccSquared = 0.00669438f;
	float k0 = 0.9996f;

	float LongOrigin;
	float eccPrimeSquared;
	float N, T, C, A, M;

	//Make sure the longitude is between -180.00 .. 179.9
	float LongTemp = (Long + 180) - int((Long + 180) / 360) * 360 - 180; // -180.00 .. 179.9;

	float LatRad = Lat*DEG2RAD;
	float LongRad = LongTemp*DEG2RAD;
	float LongOriginRad;
	int   ZoneNumber = 30;

	LongOrigin = (ZoneNumber - 1) * 6.0f - 180 + 3;  //+3 puts origin in middle of zone
	LongOriginRad = LongOrigin * DEG2RAD;

	eccPrimeSquared = (eccSquared) / (1 - eccSquared);

	N = a / sqrt(1 - eccSquared*sin(LatRad)*sin(LatRad));
	T = tan(LatRad)*tan(LatRad);
	C = eccPrimeSquared*cos(LatRad)*cos(LatRad);
	A = cos(LatRad)*(LongRad - LongOriginRad);

	M = a*((1 - eccSquared / 4 - 3 * eccSquared*eccSquared / 64 - 5 * eccSquared*eccSquared*eccSquared / 256)*LatRad
		- (3 * eccSquared / 8 + 3 * eccSquared*eccSquared / 32 + 45 * eccSquared*eccSquared*eccSquared / 1024)*sin(2 * LatRad)
		+ (15 * eccSquared*eccSquared / 256 + 45 * eccSquared*eccSquared*eccSquared / 1024)*sin(4 * LatRad)
		- (35 * eccSquared*eccSquared*eccSquared / 3072)*sin(6 * LatRad));

	UTMEasting = (k0*N*(A + (1 - T + C)*A*A*A / 6
		+ (5 - 18 * T + T*T + 72 * C - 58 * eccPrimeSquared)*A*A*A*A*A / 120)
		+ 500000.0f);

	UTMNorthing = (k0*(M + N*tan(LatRad)*(A*A / 2 + (5 - T + 9 * C + 4 * C*C)*A*A*A*A / 24
		+ (61 - 58 * T + T*T + 600 * C - 330 * eccPrimeSquared)*A*A*A*A*A*A / 720)));
	if (Lat < 0)
		UTMNorthing += 10000000.0f; //10000000 meter offset for southern hemisphere
}
